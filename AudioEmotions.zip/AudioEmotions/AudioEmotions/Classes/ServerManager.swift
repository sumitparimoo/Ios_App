//
//  ServerManager.swift
//  AudioEmotions
//
//  Created by Tejas Kharva on 11/30/16.
//  Copyright © 2016 Tejas Kharva. All rights reserved.
//

import Foundation
import Alamofire
import CoreData

class ServerManager: NSObject {
	
	static let sharedInstance = ServerManager()

	private let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext
	
	func getCall() {
		
		let requestString = "http://localhost:8080/GlassFish_HelloWorld_war_exploded/helloworld"
		let request = NSMutableURLRequest(URL: NSURL(string: requestString)!)
		request.setValue("application/json", forHTTPHeaderField: "Content-Type")
		request.HTTPMethod = "GET"
		//request.HTTPBody = try! NSJSONSerialization.dataWithJSONObject(voicesArray, options: [])
		
		Alamofire.request(request)
			.responseString { response in
				switch response.result {
				case .Success(let responseObject):
					
					print(responseObject)
					
					break
				case .Failure(let error):
					print(error)
				}
		}
	}
	
	func contentString(content: NSData? = nil) -> String {
		if (content == nil) {
			return ""
		}
//		return "\(uriPrefix())\(content!.base64EncodedStringWithOptions(.EncodingEndLineWithLineFeed))"
		return "\(content!.base64EncodedStringWithOptions(.EncodingEndLineWithLineFeed))"
	}
	
	func postAudioFile() {
		
		var audioFile: AudioFile!
		
		do {
			let request = NSFetchRequest(entityName: "AudioFile")
			let audioFileArray = try managedObjectContext.executeFetchRequest(request) as! [AudioFile]
			audioFile = audioFileArray[0]
		} catch {
			print(error)
		}
		
		let audioFileString = contentString(audioFile.content)
		let audioFileJSON = ["content" : audioFileString]
		
		let requestString = "http://localhost:8080/GlassFish_HelloWorld_war_exploded/helloworld/audio/"
		let request = NSMutableURLRequest(URL: NSURL(string: requestString)!)
		request.setValue("application/json", forHTTPHeaderField: "Content-Type")
		request.HTTPMethod = "POST"
		//request.HTTPBody = try! NSJSONSerialization.dataWithJSONObject(voicesArray, options: [])
		request.HTTPBody = try! NSJSONSerialization.dataWithJSONObject(audioFileJSON, options: [])
		
		Alamofire.request(request)
			.responseString { response in
				switch response.result {
				case .Success(let responseObject):
					
					print(responseObject)
					
					break
				case .Failure(let error):
					print(error)
				}
		}
	}
}
